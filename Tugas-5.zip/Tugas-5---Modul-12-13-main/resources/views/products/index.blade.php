@extends('template')

@section('title', 'Daftar Produk')

@section('content')
<div class="row justify-content-center mt-5">
    <div class="col-md-10">

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4>Daftar Produk</h4>
            <a href="{{ route('products.create') }}" class="btn btn-primary">Tambah Produk</a>
        </div>

        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Variant</th>
                    <th width="250">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($products as $product)
                    <tr>
                        <td>{{ $product->name }}</td>
                        <td>Rp {{ number_format($product->price, 0, ',', '.') }}</td>
                        <td>
                            @forelse($product->variants as $variant)
                                <ul>
                                    <li><strong>{{ $variant->name }}</strong></li>
                                    Desc: {{ $variant->description }} <br>
                                    Proc: {{ $variant->processor }} <br>
                                    RAM: {{ $variant->memory }} <br>
                                    Strg: {{ $variant->storage }} <br>
                                    Product: {{ $variant->product->name }}
                                </ul>
                            @empty
                                <span class="text-muted">Belum ada variant</span>
                            @endforelse
                        </td>
                        <td>
                            <a href="{{ route('variants.create', $product) }}" class="btn btn-sm btn-success mb-1">
                                Tambah Variant
                            </a>

                            <a href="{{ route('products.edit', $product->id) }}" class="btn btn-sm btn-primary mb-1">
                                Edit
                            </a>

                            <form method="POST" action="{{ route('products.destroy', $product->id) }}" style="display:inline" onsubmit="return confirm('Yakin hapus?')">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-sm btn-danger mb-1">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="text-center">Belum ada data produk</td>
                    </tr>
                @endforelse
            </tbody>
        </table>

    </div>
</div>
@endsection