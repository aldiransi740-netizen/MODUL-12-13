@extends('template')

@section('title', 'Tambah Variant')

@section('content')
<div class="row justify-content-center mt-5">
    <div class="col-md-6">

        <h4>Tambah Variant untuk {{ $product->name }}</h4>

        <form method="POST" action="{{ route('variants.store', $product) }}" class="border p-4">
            @csrf

            <div class="mb-3">
                <label class="form-label">Nama Variant</label>
                <input 
                    type="text" 
                    name="name" 
                    class="form-control @error('name') is-invalid @enderror"
                    value="{{ old('name') }}"
                >
                @error('name')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea 
                    name="description" 
                    class="form-control @error('description') is-invalid @enderror"
                >{{ old('description') }}</textarea>
                @error('description')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Processor</label>
                <input 
                    type="text" 
                    name="processor" 
                    class="form-control @error('processor') is-invalid @enderror"
                    value="{{ old('processor') }}"
                >
                @error('processor')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Memory</label>
                <input 
                    type="text" 
                    name="memory" 
                    class="form-control @error('memory') is-invalid @enderror"
                    value="{{ old('memory') }}"
                >
                @error('memory')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="mb-3">
                <label class="form-label">Storage</label>
                <input 
                    type="text" 
                    name="storage" 
                    class="form-control @error('storage') is-invalid @enderror"
                    value="{{ old('storage') }}"
                >
                @error('storage')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-success">Simpan</button>
                <a href="{{ route('products.index') }}" class="btn btn-secondary">Kembali</a>
            </div>
        </form>

    </div>
</div>
@endsection