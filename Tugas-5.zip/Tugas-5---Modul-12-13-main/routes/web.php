<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SiteController;
use App\Http\Controllers\VariantController;


Route::get('/login', [SiteController::class, 'login'])->name('login');
Route::post('/auth', [SiteController::class, 'auth'])->name('auth');
Route::post('/logout', [SiteController::class, 'logout'])->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/', function () {
        return redirect()->route('products.index');
    });

    Route::resource('products', ProductController::class);

 Route::get('/products/{product}/variants/create', [VariantController::class, 'create'])
        ->name('variants.create');

    Route::post('/products/{product}/variants', [VariantController::class, 'store'])
        ->name('variants.store');
});